# Higher Education BI Solution

Help Colleges and Universities get started with Microsoft BI.