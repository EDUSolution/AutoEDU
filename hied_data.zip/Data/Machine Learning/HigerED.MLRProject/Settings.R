# Application settings file.
# File content was generated on 6/5/2017 9:51:31 AM.

settings <- as.environment(list())

# [Category] SQL
# [Description] Database connection string
# [Editor] ConnectionStringEditor
settings$dbConnection <- 'Driver={SQL Server};Server=localhost;Database=HigherED_DW;Trusted_Connection=yes'

