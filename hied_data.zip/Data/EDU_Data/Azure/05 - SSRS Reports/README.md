# Higher Education BI Solution

SSRS Solution.

1.  Open Project
2.  Right-click on Project.
3.  Select Deploy.