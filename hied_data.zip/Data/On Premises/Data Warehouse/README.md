# Higher Education BI Solution

Data Warehouse Solution.

1.  Open Project
2.  Right-click on Project.
3.  Select Build.
4.  After success.  Right-click again and select Publish.