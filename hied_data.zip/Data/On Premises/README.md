# Higher Education BI Solution

Solutions needed to deploy BI